import React from 'react'

const Demo = () => {
  return <div>async demo</div>
}

export default Demo
