import React, { Component, Suspense } from 'react'

class Text extends Component {
  render() {
    return <div />
  }
}

export default Text
