import React, { Component } from 'react'

class Home extends Component {
  render() {
    return <div>admin home</div>
  }
}

export default Home
